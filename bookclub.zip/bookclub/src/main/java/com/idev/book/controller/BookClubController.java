package com.idev.book.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.idev.book.dto.BookRentDto;
import com.idev.book.dao.BookrentMapper;


@Controller
@RequestMapping("book/")
public class BookClubController {
	private static final Logger logger = LoggerFactory.getLogger(BookClubController.class);
	private final BookrentMapper mapper;
	
	public BookClubController(BookrentMapper mapper) {
		this.mapper=mapper;
	}
	
	//홈
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		return "home";
	}
	
	//전체 도서 목록조회 화면으로
	@RequestMapping(value="list")
	public String list(Model model) {
		logger.info(mapper.selectBooks().toString());
		model.addAttribute("list",mapper.selectBooks());
		return "book/bookList";
	}

	//도서 대여현황 조회 화면으로
	@RequestMapping("rentList")
	public String return_(Model model) {
		int cnt = mapper.updateDelays();
		
		model.addAttribute("list", mapper.getRentList());
		model.addAttribute("delay_cnt",cnt);
		model.addAttribute("rent_cnt",mapper.countRents());
		return "book/rentList";
	}
	
	//도서 대여 화면으로
	@GetMapping("rent")
	public String rent(Model model) {
		model.addAttribute("bclist", mapper.bcodes());
		return "book/bookRent";
	}
	
	//문제 : 도서 대여 처리
	@PostMapping("rent")
	public String rent(BookRentDto dto,RedirectAttributes rdattr) {
		
		
		return "redirect:rentList";
	}
		
	
}
